// Re-export useTheme hook for convenience
export { useTheme } from './theme.provider';

