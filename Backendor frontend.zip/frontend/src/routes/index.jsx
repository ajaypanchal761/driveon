import { createBrowserRouter, Navigate } from "react-router-dom";
import { lazy } from "react";
import AdminRoute from "../components/layout/AdminRoute";
import AdminLayout from "../components/admin/layout/AdminLayout";
import ModuleLayout from "../module/components/layout/ModuleLayout";
import { useAdminAuth } from "../context/AdminContext";
import RouteErrorBoundary from "../components/common/RouteErrorBoundary";

// Module pages (new frontend)
const ModuleHomePage = lazy(() => import("../module/pages/HomePage"));
const ModuleSearchPage = lazy(() => import("../module/pages/SearchPage"));
const ModuleCarDetailsPage = lazy(() => 
  import("../module/pages/CarDetailsPage").catch((error) => {
    console.error("Failed to load CarDetailsPage:", error);
    // Return a fallback component
    return {
      default: () => (
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-4">Failed to load page</h1>
            <p className="text-gray-600 mb-4">{error.message}</p>
            <button
              onClick={() => window.location.reload()}
              className="px-4 py-2 bg-blue-600 text-white rounded"
            >
              Reload
            </button>
          </div>
        </div>
      ),
    };
  })
);
const ModuleCarReviewsPage = lazy(() => import("../module/pages/CarReviewsPage"));
const ModuleProfilePage = lazy(() => import("../module/pages/ModuleProfilePage"));
const ModuleCompleteProfilePage = lazy(() => import("../module/pages/ModuleCompleteProfilePage"));
const ModuleEditProfilePage = lazy(() => import("../module/pages/ModuleEditProfilePage"));
const ModuleChangePasswordPage = lazy(() => import("../module/pages/ModuleChangePasswordPage"));
const ModuleKYCStatusPage = lazy(() => import("../module/pages/ModuleKYCStatusPage"));
const ModuleGuarantorPage = lazy(() => import("../module/pages/ModuleGuarantorPage"));
const ModuleReferralDashboardPage = lazy(() => import("../module/pages/ModuleReferralDashboardPage"));
const ModuleSettingsPage = lazy(() => import("../module/pages/ModuleSettingsPage"));
const ModuleSupportPage = lazy(() => import("../module/pages/ModuleSupportPage"));
const ModuleLoginPage = lazy(() => import("../module/pages/LoginPage"));
const ModuleRegisterPage = lazy(() => import("../module/pages/RegisterPage"));
const ModuleBookingsPage = lazy(() => import("../module/pages/BookingsPage"));
const ModuleBookNowPage = lazy(() => import("../module/pages/BookNowPage"));
const ModuleWriteReviewPage = lazy(() => import("../module/pages/ModuleWriteReviewPage"));
const ModuleFAQPage = lazy(() => import("../module/pages/FAQPage"));
const ModuleAboutPage = lazy(() => import("../module/pages/AboutPage"));
const ModuleContactPage = lazy(() => import("../module/pages/ContactPage"));
const ModulePrivacyPolicyPage = lazy(() => import("../module/pages/PrivacyPolicyPage"));
const ModuleTermsAndConditionsPage = lazy(() => import("../module/pages/TermsAndConditionsPage"));

// Admin pages
const AdminDashboardPage = lazy(() =>
  import("../pages/admin/AdminDashboardPage")
);
const UserListPage = lazy(() =>
  import("../pages/admin/users/UserListPage")
);
const KYCListPage = lazy(() =>
  import("../pages/admin/kyc/KYCListPage")
);
const GuarantorListPage = lazy(() =>
  import("../pages/admin/guarantors/GuarantorListPage")
);
const CarListPage = lazy(() =>
  import("../pages/admin/cars/CarListPage")
);
const AddCarPage = lazy(() =>
  import("../pages/admin/cars/AddCarPage")
);
const EditCarPage = lazy(() =>
  import("../pages/admin/cars/EditCarPage")
);
const BookingListPage = lazy(() =>
  import("../pages/admin/bookings/BookingListPage")
);
const PaymentListPage = lazy(() =>
  import("../pages/admin/payments/PaymentListPage")
);
const TrackingPage = lazy(() =>
  import("../pages/admin/tracking/TrackingPage")
);
const ReferralManagementPage = lazy(() =>
  import("../pages/admin/referrals/ReferralManagementPage")
);
const CouponManagementPage = lazy(() =>
  import("../pages/admin/coupons/CouponManagementPage")
);
const AdminSettingsPage = lazy(() =>
  import("../pages/admin/settings/AdminSettingsPage")
);
const AdminProfilePage = lazy(() =>
  import("../pages/admin/profile/AdminProfilePage")
);
const AdminSupportPage = lazy(() =>
  import("../pages/admin/support/AdminSupportPage")
);
const AdminLoginPage = lazy(() =>
  import("../pages/admin/AdminLoginPage")
);
const NotFoundPage = lazy(() => import("../pages/NotFoundPage"));

/**
 * AdminRedirectRoute Component
 * Handles /admin route - redirects to dashboard if authenticated, login if not
 */
const AdminRedirectRoute = () => {
  const { isAuthenticated, isLoading } = useAdminAuth();
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-white">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 mx-auto mb-4 border-purple-600"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }
  
  if (isAuthenticated) {
    return <Navigate to="/admin/dashboard" replace />;
  }
  
  return <Navigate to="/admin/login" replace />;
};

// Create router configuration
const router = createBrowserRouter([
  // Module routes (new frontend) - wrapped with ModuleLayout
  {
    element: <ModuleLayout />,
    children: [
      {
        path: "/",
        element: <ModuleHomePage />,
      },
      {
        path: "/login",
        element: <ModuleLoginPage />,
      },
      {
        path: "/register",
        element: <ModuleRegisterPage />,
      },
      {
        path: "/search",
        element: <ModuleSearchPage />,
      },
      {
        path: "/car-details/:id",
        element: <ModuleCarDetailsPage />,
        errorElement: <RouteErrorBoundary />,
      },
      {
        path: "/car-details/:id/reviews",
        element: <ModuleCarReviewsPage />,
      },
      {
        path: "/book-now/:id",
        element: <ModuleBookNowPage />,
      },
      {
        path: "/profile",
        element: <ModuleProfilePage />,
      },
      {
        path: "/profile/complete",
        element: <ModuleCompleteProfilePage />,
      },
      {
        path: "/profile/edit",
        element: <ModuleEditProfilePage />,
      },
      {
        path: "/profile/change-password",
        element: <ModuleChangePasswordPage />,
      },
      {
        path: "/profile/kyc",
        element: <ModuleKYCStatusPage />,
      },
      {
        path: "/profile/guarantor",
        element: <ModuleGuarantorPage />,
      },
      {
        path: "/profile/referrals",
        element: <ModuleReferralDashboardPage />,
      },
      {
        path: "/profile/settings",
        element: <ModuleSettingsPage />,
      },
      {
        path: "/profile/support",
        element: <ModuleSupportPage />,
      },
      {
        path: "/bookings",
        element: <ModuleBookingsPage />,
      },
      {
        path: "/write-review/:bookingId",
        element: <ModuleWriteReviewPage />,
      },
      {
        path: "/faq",
        element: <ModuleFAQPage />,
      },
      {
        path: "/about",
        element: <ModuleAboutPage />,
      },
      {
        path: "/contact",
        element: <ModuleContactPage />,
      },
      {
        path: "/privacy-policy",
        element: <ModulePrivacyPolicyPage />,
      },
      {
        path: "/terms",
        element: <ModuleTermsAndConditionsPage />,
      },
    ],
  },
  // Admin Auth Routes (public - no authentication required)
  {
    path: "/admin/login",
    element: <AdminLoginPage />,
  },
  // Admin root route - redirects based on authentication
  {
    path: "/admin",
    element: <AdminRedirectRoute />,
  },
  // Admin Routes (require admin role and use AdminLayout)
  {
    element: <AdminRoute />,
    children: [
      {
        element: <AdminLayout />,
        children: [
          {
            path: "/admin/dashboard",
            element: <AdminDashboardPage />,
          },
          {
            path: "/admin/users",
            element: <UserListPage />,
          },
          {
            path: "/admin/kyc",
            element: <KYCListPage />,
          },
          {
            path: "/admin/kyc/pending",
            element: <KYCListPage />,
          },
          {
            path: "/admin/kyc/approved",
            element: <KYCListPage />,
          },
          {
            path: "/admin/kyc/rejected",
            element: <KYCListPage />,
          },
          {
            path: "/admin/guarantors",
            element: <GuarantorListPage />,
          },
          {
            path: "/admin/guarantors/pending",
            element: <GuarantorListPage />,
          },
          {
            path: "/admin/cars",
            element: <CarListPage />,
          },
          {
            path: "/admin/cars/new",
            element: <AddCarPage />,
          },
          {
            path: "/admin/cars/:carId/edit",
            element: <EditCarPage />,
          },
          {
            path: "/admin/cars/pending",
            element: <CarListPage />,
          },
          {
            path: "/admin/bookings",
            element: <BookingListPage />,
          },
          {
            path: "/admin/bookings/pending",
            element: <BookingListPage />,
          },
          {
            path: "/admin/bookings/active",
            element: <BookingListPage />,
          },
          {
            path: "/admin/payments",
            element: <PaymentListPage />,
          },
          {
            path: "/admin/payments/pending",
            element: <PaymentListPage />,
          },
          {
            path: "/admin/payments/failed",
            element: <PaymentListPage />,
          },
          {
            path: "/admin/tracking",
            element: <TrackingPage />,
          },
          {
            path: "/admin/tracking/active",
            element: <TrackingPage />,
          },
          {
            path: "/admin/tracking/history",
            element: <TrackingPage />,
          },
          {
            path: "/admin/referrals",
            element: <ReferralManagementPage />,
          },
          {
            path: "/admin/referrals/statistics",
            element: <ReferralManagementPage />,
          },
          {
            path: "/admin/referrals/top-referrers",
            element: <ReferralManagementPage />,
          },
          {
            path: "/admin/coupons",
            element: <CouponManagementPage />,
          },
          {
            path: "/admin/support",
            element: <AdminSupportPage />,
          },
          {
            path: "/admin/settings",
            element: <AdminSettingsPage />,
          },
          {
            path: "/admin/settings/notifications",
            element: <AdminSettingsPage />,
          },
          {
            path: "/admin/settings/security",
            element: <AdminSettingsPage />,
          },
          {
            path: "/admin/settings/features",
            element: <AdminSettingsPage />,
          },
          {
            path: "/admin/profile",
            element: <AdminProfilePage />,
          },
        ],
      },
    ],
  },
  // 404 Page
  {
    path: "*",
    element: <NotFoundPage />,
  },
]);

export default router;
